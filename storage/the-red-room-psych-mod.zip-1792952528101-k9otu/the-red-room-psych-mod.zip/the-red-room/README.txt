Psych Online mod generated from osu!mania 4K.

Song: (The) Red * Room
Artist: Camellia

Installation:
1. Extract this folder into your Psych Engine mods directory.
2. Select the mod from the Mods menu.
3. Ensure audio is OGG Vorbis named Inst.ogg.

Notes:
- Converted charts use 4 lanes mapped to left/down/up/right.
- needsVoices is set to false (instrumental only).
- If the original audio was not OGG, convert it to OGG Vorbis and replace Inst.ogg.
